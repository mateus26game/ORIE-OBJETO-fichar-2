package ativi3;

public class ativivda3 {public static void main(String[] args) {
	
	 ativiviQ3 toppp = new ativiviQ3();
	 toppp.quest();
}

}
