package segunda;

public class questao22 {public static void main(String[] args) {
	
	sengudaQ2 topp = new sengudaQ2();
	topp.questae();
	
}

}
