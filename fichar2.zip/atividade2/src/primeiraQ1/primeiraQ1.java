package primeiraQ1;
public class primeiraQ1 {public static void main(String[] args) {
	
	primeiraquestao top = new primeiraquestao();
	top. questa();
	
}
 
}
